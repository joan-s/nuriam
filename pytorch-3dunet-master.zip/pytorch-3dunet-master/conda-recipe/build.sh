$PYTHON setup.py install
